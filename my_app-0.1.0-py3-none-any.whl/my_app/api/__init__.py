"""REST API module for my_app app."""
