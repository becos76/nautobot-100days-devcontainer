"""Unit tests for my_app app."""
